import { GenerationProvider } from "./types";
import { MockProvider } from "./mock-provider";

/**
 * Provider factory. Add your provider's case here once you've implemented
 * GenerationProvider in a new file (e.g. `./acme-provider.ts`):
 *
 *   import { AcmeProvider } from "./acme-provider";
 *   case "acme":
 *     return new AcmeProvider({
 *       apiKey: requireEnv("GEN_PROVIDER_API_KEY"),
 *       apiUrl: requireEnv("GEN_PROVIDER_API_URL"),
 *     });
 *
 * Then set GENERATION_PROVIDER=acme in your environment.
 */
export function getProvider(): GenerationProvider {
  const providerName = process.env.GENERATION_PROVIDER ?? "mock";

  switch (providerName) {
    case "mock":
      return new MockProvider();
    default:
      throw new Error(
        `Unknown GENERATION_PROVIDER "${providerName}". ` +
          `Register it in lib/providers/index.ts.`
      );
  }
}

export function requireEnv(name: string): string {
  const value = process.env[name];
  if (!value) throw new Error(`Missing required env var: ${name}`);
  return value;
}
