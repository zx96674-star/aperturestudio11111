/**
 * GenerationProvider is the single interface every image/video backend must
 * implement. Swap providers by adding a new file in this folder and
 * registering it in `index.ts` — nothing else in the app needs to change.
 */

export type AspectRatio = "1:1" | "4:5" | "9:16" | "16:9";
export type Quality = "draft" | "standard" | "high";

export interface ImageGenParams {
  prompt: string;
  negativePrompt?: string;
  style?: string;
  aspectRatio: AspectRatio;
  quality: Quality;
  seed?: number;
}

export interface VideoGenParams {
  prompt: string;
  negativePrompt?: string;
  style?: string;
  aspectRatio: AspectRatio;
  quality: Quality;
  durationSec: number; // e.g. 4-12s for short clips
  seed?: number;
}

export interface ImageToVideoParams {
  sourceImageUrl: string;
  prompt?: string; // optional motion/camera guidance
  durationSec: number;
  quality: Quality;
}

export interface GenerationResult {
  type: "image" | "video";
  url: string;
  thumbnailUrl?: string;
  width?: number;
  height?: number;
  providerRef?: string; // provider's own job/asset id, for auditing
}

export interface GenerationProvider {
  /** Human-readable name, surfaced in job records for auditing. */
  readonly name: string;

  generateImage(params: ImageGenParams): Promise<GenerationResult>;
  generateVideo(params: VideoGenParams): Promise<GenerationResult>;
  animateImage(params: ImageToVideoParams): Promise<GenerationResult>;
}

/**
 * Thrown by a provider when it refuses to generate content (its own safety
 * system, not ours). API routes catch this separately from generic errors
 * so the client gets a clear "content policy" message instead of a 500.
 */
export class ProviderPolicyError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ProviderPolicyError";
  }
}
