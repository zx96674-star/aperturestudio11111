import {
  GenerationProvider,
  ImageGenParams,
  VideoGenParams,
  ImageToVideoParams,
  GenerationResult,
} from "./types";

const DIMENSIONS: Record<string, { w: number; h: number }> = {
  "1:1": { w: 1024, h: 1024 },
  "4:5": { w: 1024, h: 1280 },
  "9:16": { w: 1080, h: 1920 },
  "16:9": { w: 1920, h: 1080 },
};

function fakeDelay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * MockProvider stands in for a real generation API. It returns deterministic
 * placeholder gradient-image / sample-clip URLs so the full app (history,
 * gallery, downloads) is exercisable with zero external dependencies or keys.
 *
 * Replace this with a real provider by implementing GenerationProvider
 * against your chosen image/video API and registering it in ./index.ts.
 */
export class MockProvider implements GenerationProvider {
  readonly name = "mock";

  async generateImage(params: ImageGenParams): Promise<GenerationResult> {
    await fakeDelay(900);
    const { w, h } = DIMENSIONS[params.aspectRatio];
    return {
      type: "image",
      // picsum.photos gives a real, varied placeholder image sized to the
      // requested aspect ratio — swap for your provider's returned asset URL.
      url: `https://picsum.photos/seed/${encodeURIComponent(params.prompt).slice(0, 40)}-${Date.now()}/${w}/${h}`,
      width: w,
      height: h,
      providerRef: `mock-img-${Date.now()}`,
    };
  }

  async generateVideo(params: VideoGenParams): Promise<GenerationResult> {
    await fakeDelay(1500);
    const { w, h } = DIMENSIONS[params.aspectRatio];
    return {
      type: "video",
      // Sample placeholder clip — replace with the provider's rendered asset.
      url: "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4",
      thumbnailUrl: `https://picsum.photos/seed/${encodeURIComponent(params.prompt).slice(0, 40)}/${w}/${h}`,
      width: w,
      height: h,
      providerRef: `mock-vid-${Date.now()}`,
    };
  }

  async animateImage(params: ImageToVideoParams): Promise<GenerationResult> {
    await fakeDelay(1500);
    return {
      type: "video",
      url: "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4",
      thumbnailUrl: params.sourceImageUrl,
      providerRef: `mock-i2v-${Date.now()}`,
    };
  }
}
