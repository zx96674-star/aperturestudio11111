/**
 * Pre-generation prompt moderation. Runs before any provider call.
 *
 * This is a scaffold: keyword/length checks only. Before handling untrusted
 * traffic, replace the marked sections with real classifiers (a hosted
 * NSFW/CSAM classifier, an age-signal model, a named-real-person matcher).
 * This layer is a first line of defense, not a substitute for the
 * generation provider's own content-safety systems.
 */

export interface ModerationResult {
  allowed: boolean;
  reason?: string;
}

const MAX_PROMPT_LENGTH = 2000;

// Minimal illustrative blocklist. Replace with a real classifier — a static
// list is trivially evaded and is not a serious safety control on its own.
const BLOCKED_PATTERNS: RegExp[] = [/\bchild\b.*\b(nude|naked|sexual)\b/i];

export async function moderatePrompt(
  prompt: string
): Promise<ModerationResult> {
  if (!prompt || !prompt.trim()) {
    return { allowed: false, reason: "Prompt is empty." };
  }
  if (prompt.length > MAX_PROMPT_LENGTH) {
    return { allowed: false, reason: "Prompt exceeds maximum length." };
  }

  for (const pattern of BLOCKED_PATTERNS) {
    if (pattern.test(prompt)) {
      return { allowed: false, reason: "Prompt violates content policy." };
    }
  }

  // --- Extension point: real-person / public-figure matcher ---
  // const namedPersonHit = await checkAgainstKnownPeopleIndex(prompt);
  // if (namedPersonHit) return { allowed: false, reason: "..." };

  // --- Extension point: hosted NSFW / age-signal classifier ---
  // const classifierResult = await callModerationClassifier(prompt);
  // if (!classifierResult.safe) return { allowed: false, reason: classifierResult.reason };

  return { allowed: true };
}
