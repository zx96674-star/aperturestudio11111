"use client";

import { useEffect, useState } from "react";
import PromptBox from "@/components/PromptBox";
import CharacterSettings, { SubjectAttributes } from "@/components/CharacterSettings";
import StyleSelector from "@/components/StyleSelector";
import ModeToggle, { Mode } from "@/components/ModeToggle";
import GenerationSettings from "@/components/GenerationSettings";
import ResultsGallery, { ResultItem } from "@/components/ResultsGallery";
import HistoryPanel, { HistoryJob } from "@/components/HistoryPanel";

export default function StudioPage() {
  const [mode, setMode] = useState<Mode>("TEXT_TO_IMAGE");
  const [prompt, setPrompt] = useState("");
  const [negativePrompt, setNegativePrompt] = useState("");
  const [style, setStyle] = useState("editorial");
  const [subject, setSubject] = useState<SubjectAttributes>({
    setting: "Studio",
    lighting: "Soft daylight",
    palette: "Warm neutrals",
    mood: "Calm",
  });
  const [aspectRatio, setAspectRatio] = useState("1:1");
  const [quality, setQuality] = useState("standard");
  const [durationSec, setDurationSec] = useState(6);

  const [results, setResults] = useState<ResultItem[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<HistoryJob[]>([]);

  async function loadHistory() {
    try {
      const res = await fetch("/api/history");
      if (!res.ok) return; // e.g. 401 when signed out — history stays empty
      const data = await res.json();
      setHistory(data.jobs ?? []);
    } catch {
      // Non-fatal: history is a convenience panel, not core to generation.
    }
  }

  useEffect(() => {
    loadHistory();
  }, []);

  async function handleGenerate() {
    if (!prompt.trim() || isGenerating) return;
    setIsGenerating(true);
    setError(null);

    try {
      const composedPrompt = [
        prompt,
        `setting: ${subject.setting}`,
        `lighting: ${subject.lighting}`,
        `palette: ${subject.palette}`,
        `mood: ${subject.mood}`,
      ].join(", ");

      const res = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mode,
          prompt: composedPrompt,
          negativePrompt: negativePrompt || undefined,
          style,
          aspectRatio,
          quality,
          durationSec: mode !== "TEXT_TO_IMAGE" ? durationSec : undefined,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error ?? "Generation failed. Please try again.");
        return;
      }

      setResults((prev) => [
        {
          id: data.creation.id,
          type: data.creation.type,
          url: data.creation.url,
          thumbnailUrl: data.creation.thumbnailUrl,
          saved: false,
        },
        ...prev,
      ]);
      loadHistory();
    } catch {
      setError("Couldn't reach the server. Check your connection and try again.");
    } finally {
      setIsGenerating(false);
    }
  }

  async function handleSaveToggle(id: string, saved: boolean) {
    setResults((prev) =>
      prev.map((r) => (r.id === id ? { ...r, saved } : r))
    );
    try {
      await fetch("/api/creations", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, saved }),
      });
    } catch {
      // Revert optimistic update on failure.
      setResults((prev) =>
        prev.map((r) => (r.id === id ? { ...r, saved: !saved } : r))
      );
    }
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 sm:py-8">
      <div className="mb-6">
        <h1 className="font-display text-2xl font-semibold sm:text-3xl">
          Studio
        </h1>
        <p className="mt-1 text-sm text-ink-muted">
          Describe what you want, tune the settings, and generate.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-[380px_1fr]">
        {/* Control panel */}
        <div className="space-y-4 lg:sticky lg:top-20 lg:self-start">
          <ModeToggle value={mode} onChange={setMode} />

          <PromptBox
            prompt={prompt}
            negativePrompt={negativePrompt}
            onPromptChange={setPrompt}
            onNegativePromptChange={setNegativePrompt}
          />

          {mode === "IMAGE_TO_VIDEO" && (
            <div className="panel p-4 sm:p-5">
              <span className="label-eyebrow">Source image</span>
              <div className="control-input mt-2 flex h-24 items-center justify-center text-xs text-ink-faint">
                Upload not wired to storage in this scaffold — connect to
                object storage (S3/GCS) before enabling.
              </div>
            </div>
          )}

          <CharacterSettings value={subject} onChange={setSubject} />
          <StyleSelector value={style} onChange={setStyle} />
          <GenerationSettings
            mode={mode}
            aspectRatio={aspectRatio}
            quality={quality}
            durationSec={durationSec}
            onAspectRatioChange={setAspectRatio}
            onQualityChange={setQuality}
            onDurationChange={setDurationSec}
          />

          <button
            onClick={handleGenerate}
            disabled={!prompt.trim() || isGenerating}
            className="flex w-full items-center justify-center gap-2 rounded-lg bg-brass px-4 py-3 font-medium text-base transition hover:bg-brass/90 disabled:cursor-not-allowed disabled:opacity-40"
          >
            {isGenerating ? (
              <>
                <span className="iris h-4 w-4 animate-iris-spin" aria-hidden />
                Generating…
              </>
            ) : (
              "Generate"
            )}
          </button>
        </div>

        {/* Results + history */}
        <div className="space-y-5">
          <ResultsGallery
            items={results}
            isGenerating={isGenerating}
            error={error}
            onSaveToggle={handleSaveToggle}
          />
          <HistoryPanel jobs={history} onReuse={setPrompt} />
        </div>
      </div>
    </div>
  );
}
