"use client";

import { useEffect, useState } from "react";

interface Creation {
  id: string;
  type: "IMAGE" | "VIDEO";
  url: string;
  thumbnailUrl?: string | null;
  createdAt: string;
}

export default function GalleryPage() {
  const [creations, setCreations] = useState<Creation[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/creations")
      .then((res) => {
        if (!res.ok) throw new Error();
        return res.json();
      })
      .then((data) => setCreations(data.creations ?? []))
      .catch(() => setError("Couldn't load your gallery. Try refreshing."))
      .finally(() => setLoading(false));
  }, []);

  async function handleRemove(id: string) {
    setCreations((prev) => prev.filter((c) => c.id !== id));
    try {
      await fetch(`/api/creations?id=${id}`, { method: "DELETE" });
    } catch {
      // Best-effort — a stale item reappearing on next load is an acceptable
      // failure mode here; a production build should re-fetch/reconcile.
    }
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 sm:py-8">
      <h1 className="font-display text-2xl font-semibold sm:text-3xl">Gallery</h1>
      <p className="mt-1 text-sm text-ink-muted">
        Everything you've saved from the studio.
      </p>

      {error && (
        <div className="mt-6 rounded-lg border border-danger/40 bg-danger/10 px-3 py-2.5 text-sm text-danger">
          {error}
        </div>
      )}

      {loading ? (
        <div className="mt-10 flex justify-center">
          <span className="iris h-8 w-8 animate-iris-spin" aria-hidden />
        </div>
      ) : creations.length === 0 ? (
        <div className="mt-10 flex flex-col items-center gap-2 rounded-panel border border-dashed border-line py-16 text-center">
          <span className="iris h-8 w-8 opacity-40" aria-hidden />
          <p className="text-sm text-ink-muted">Your gallery is empty.</p>
          <p className="text-xs text-ink-faint">
            Save a result from the studio to see it here.
          </p>
        </div>
      ) : (
        <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
          {creations.map((item) => (
            <figure
              key={item.id}
              className="group relative overflow-hidden rounded-panel border border-line bg-raised"
            >
              {item.type === "IMAGE" ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={item.url}
                  alt=""
                  className="aspect-square w-full object-cover"
                  loading="lazy"
                />
              ) : (
                <video
                  src={item.url}
                  poster={item.thumbnailUrl ?? undefined}
                  className="aspect-square w-full object-cover"
                  muted
                  loop
                  controls
                />
              )}
              <div className="absolute inset-x-0 bottom-0 flex justify-between gap-2 bg-gradient-to-t from-base/90 to-transparent p-2 opacity-0 transition group-hover:opacity-100">
                <a
                  href={item.url}
                  download
                  className="rounded-md border border-line bg-base/80 px-2 py-1 text-xs hover:border-cyan"
                >
                  Download
                </a>
                <button
                  onClick={() => handleRemove(item.id)}
                  className="rounded-md border border-line bg-base/80 px-2 py-1 text-xs hover:border-danger"
                >
                  Remove
                </button>
              </div>
            </figure>
          ))}
        </div>
      )}
    </div>
  );
}
