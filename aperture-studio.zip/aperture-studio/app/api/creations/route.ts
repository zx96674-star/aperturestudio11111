import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";

// GET  /api/creations         -> list saved gallery items
// PATCH /api/creations        -> { id, saved } toggle save-to-gallery
// DELETE /api/creations?id=.. -> remove a creation

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
  }
  const userId = (session.user as any).id as string;

  const creations = await db.creation.findMany({
    where: { userId, saved: true },
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json({ creations });
}

export async function PATCH(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
  }
  const userId = (session.user as any).id as string;
  const { id, saved } = await req.json();

  const creation = await db.creation.findFirst({ where: { id, userId } });
  if (!creation) {
    return NextResponse.json({ error: "Not found." }, { status: 404 });
  }

  const updated = await db.creation.update({
    where: { id },
    data: { saved: Boolean(saved) },
  });

  return NextResponse.json({ creation: updated });
}

export async function DELETE(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
  }
  const userId = (session.user as any).id as string;
  const id = req.nextUrl.searchParams.get("id");
  if (!id) {
    return NextResponse.json({ error: "Missing id." }, { status: 400 });
  }

  const creation = await db.creation.findFirst({ where: { id, userId } });
  if (!creation) {
    return NextResponse.json({ error: "Not found." }, { status: 404 });
  }

  await db.creation.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
