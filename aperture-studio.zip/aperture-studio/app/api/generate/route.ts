import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { z } from "zod";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";
import { moderatePrompt } from "@/lib/moderation";
import { getProvider } from "@/lib/providers";
import { ProviderPolicyError } from "@/lib/providers/types";

const RequestSchema = z.object({
  mode: z.enum(["TEXT_TO_IMAGE", "TEXT_TO_VIDEO", "IMAGE_TO_VIDEO"]),
  prompt: z.string().min(1).max(2000),
  negativePrompt: z.string().max(1000).optional(),
  style: z.string().optional(),
  aspectRatio: z.enum(["1:1", "4:5", "9:16", "16:9"]),
  quality: z.enum(["draft", "standard", "high"]),
  durationSec: z.number().min(1).max(20).optional(),
  sourceImageUrl: z.string().url().optional(),
  characterId: z.string().optional(),
});

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
  }
  const userId = (session.user as any).id as string;

  const body = await req.json().catch(() => null);
  const parsed = RequestSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Invalid request.", details: parsed.error.flatten() },
      { status: 400 }
    );
  }
  const input = parsed.data;

  if (input.mode === "IMAGE_TO_VIDEO" && !input.sourceImageUrl) {
    return NextResponse.json(
      { error: "sourceImageUrl is required for image-to-video." },
      { status: 400 }
    );
  }

  // 1. Create the job record in PENDING/MODERATING state up front, so every
  //    attempt — allowed or rejected — is auditable.
  const job = await db.generationJob.create({
    data: {
      userId,
      characterId: input.characterId,
      mode: input.mode,
      prompt: input.prompt,
      negativePrompt: input.negativePrompt,
      style: input.style,
      aspectRatio: input.aspectRatio,
      quality: input.quality,
      durationSec: input.durationSec,
      sourceImageUrl: input.sourceImageUrl,
      status: "MODERATING",
    },
  });

  // 2. Moderate before touching the provider.
  const moderation = await moderatePrompt(
    `${input.prompt} ${input.negativePrompt ?? ""}`
  );
  if (!moderation.allowed) {
    await db.generationJob.update({
      where: { id: job.id },
      data: { status: "REJECTED", rejectReason: moderation.reason },
    });
    return NextResponse.json(
      { error: moderation.reason ?? "Prompt rejected by content policy." },
      { status: 422 }
    );
  }

  await db.generationJob.update({
    where: { id: job.id },
    data: { status: "GENERATING" },
  });

  // 3. Call the (swappable) generation provider.
  const provider = getProvider();
  try {
    const result =
      input.mode === "TEXT_TO_IMAGE"
        ? await provider.generateImage({
            prompt: input.prompt,
            negativePrompt: input.negativePrompt,
            style: input.style,
            aspectRatio: input.aspectRatio,
            quality: input.quality,
          })
        : input.mode === "TEXT_TO_VIDEO"
        ? await provider.generateVideo({
            prompt: input.prompt,
            negativePrompt: input.negativePrompt,
            style: input.style,
            aspectRatio: input.aspectRatio,
            quality: input.quality,
            durationSec: input.durationSec ?? 6,
          })
        : await provider.animateImage({
            sourceImageUrl: input.sourceImageUrl!,
            prompt: input.prompt,
            durationSec: input.durationSec ?? 6,
            quality: input.quality,
          });

    const creation = await db.creation.create({
      data: {
        userId,
        jobId: job.id,
        type: result.type === "image" ? "IMAGE" : "VIDEO",
        url: result.url,
        thumbnailUrl: result.thumbnailUrl,
        width: result.width,
        height: result.height,
      },
    });

    await db.generationJob.update({
      where: { id: job.id },
      data: {
        status: "COMPLETE",
        completedAt: new Date(),
        providerName: provider.name,
        providerRef: result.providerRef,
      },
    });

    return NextResponse.json({ job, creation }, { status: 201 });
  } catch (err) {
    if (err instanceof ProviderPolicyError) {
      await db.generationJob.update({
        where: { id: job.id },
        data: { status: "REJECTED", rejectReason: err.message },
      });
      return NextResponse.json({ error: err.message }, { status: 422 });
    }

    await db.generationJob.update({
      where: { id: job.id },
      data: { status: "FAILED" },
    });
    console.error("Generation failed:", err);
    return NextResponse.json(
      { error: "Generation failed. Please try again." },
      { status: 502 }
    );
  }
}
