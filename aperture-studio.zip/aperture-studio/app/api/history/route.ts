import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
  }
  const userId = (session.user as any).id as string;

  const cursor = req.nextUrl.searchParams.get("cursor") ?? undefined;
  const take = 20;

  const jobs = await db.generationJob.findMany({
    where: { userId },
    orderBy: { createdAt: "desc" },
    take: take + 1,
    ...(cursor ? { cursor: { id: cursor }, skip: 1 } : {}),
    include: { creations: true },
  });

  const hasMore = jobs.length > take;
  const page = hasMore ? jobs.slice(0, take) : jobs;

  return NextResponse.json({
    jobs: page,
    nextCursor: hasMore ? page[page.length - 1].id : null,
  });
}
